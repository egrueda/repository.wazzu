# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Kodi Add-on for http://arenavision.ezy.es
# Version 1.0.3
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------
# Changelog:
# 1.0.3
# - First public release
# 1.0.2
# - Minor fixes
# 1.0.1
# - Use public URL
# 1.0.0
# - First release
#---------------------------------------------------------------------------

import os
import sys
import plugintools
import urllib
import urllib2
import json
import xbmcgui
import xbmcaddon
import xbmcplugin

addon         = xbmcaddon.Addon('plugin.video.arenavisionezy')
addon_name    = addon.getAddonInfo('name')
addon_version = addon.getAddonInfo('version')

# Entry point
def run():
    plugintools.log("arenavisionezy.run")

    # Get params
    params = plugintools.get_params()
    plugintools.log("arenavisionezy.run "+repr(params))

    if params.get("action") is None:
        plugintools.log("arenavisionezy.run No hay accion")
        listado_categorias(params)
    else:
        action = params.get("action")
        plugintools.log("arenavisionezy.run Accion: " + action)
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def listado_categorias(params):
  plugintools.log("arenavisionezy.listado_categorias "+repr(params))

  jsonUrl = 'http://arenavision.esy.es/json.php'
  plugintools.log("arenavisionezy.listado_categorias Parsing: " + jsonUrl)
  jsonSrc = urllib2.urlopen(jsonUrl)

  datos = json.load(jsonSrc)
  categorias  = datos['categories']
  last_update = datos['last_update']
  
  # Informacion del evento
  titulo01 = "                    [COLOR skyblue]ArenaVision EZY[/COLOR] Version "+addon_version+" (by Wazzu)"
  titulo02 = "                    [COLOR deepskyblue]Ultima actualizacion: "+last_update+"[/COLOR]"
  plugintools.add_item( title = titulo01 , folder = False )
  plugintools.add_item( title = titulo02 , folder = False )

  for categoria in categorias:
      plugintools.add_item(
        action     = "listado_eventos" , 
        title      = categoria['categoria'] + " (" +  categoria['items'] + " eventos)", 
        plot       = '' , 
        url        = "plugin://plugin.video.arenavisionezy/?action=listado_eventos&cat="+urllib.quote(categoria['categoria']),
        thumbnail  = "",
        isPlayable = True, 
        folder     = True
      )

# Listado de eventos de una categoria
def listado_eventos(params):
  plugintools.log("arenavisionezy.listado_eventos "+repr(params))
  categoria = params['cat']
  
  # Parse json
  jsonUrl = 'http://arenavision.esy.es/json.php?cat='+urllib.quote(categoria)
  plugintools.log("arenavisionezy.listado_eventos Parsing: " + jsonUrl)
  jsonSrc     = urllib2.urlopen(jsonUrl)
  datos       = json.load(jsonSrc)
  eventos     = datos['eventos']
  last_update = datos['last_update']

  # Titulo de la categoria
  titulo01 = "                [COLOR skyblue]"+categoria+"[/COLOR] (actualizado: "+last_update+")"
  plugintools.add_item( title = titulo01 , action='', url='', isPlayable = False, folder = False )
  
  # Para cada evento
  for evento in eventos:
    title     = "[COLOR skyblue]" + evento['fecha'] + " " + evento['hora'] + "[/COLOR] " + evento['titulo']
    plot      = ""
    thumbnail = ""
    url       = "plugin://plugin.video.arenavisionezy/?action=listado_canales&evento="+evento['id']
    plugintools.add_item(
      action="listado_canales" , 
      title=title , 
      plot=plot , 
      url=url ,
      thumbnail=thumbnail , 
      isPlayable=True, 
      folder=True
    )

# Listado de canales de un evento
def listado_canales(params):
  plugintools.log("arenavisionezy.listado_canales "+repr(params))
  evento = params['evento']
  
  # Parse json
  jsonUrl = 'http://arenavision.esy.es/json.php?evento='+evento
  plugintools.log("arenavisionezy.listado_canales Parsing: " + jsonUrl)
  jsonSrc   = urllib2.urlopen(jsonUrl)
  evento    = json.load(jsonSrc)
  
  # Datos del evento
  categoria = evento['categoria']
  titulo    = evento['titulo']
  fecha     = evento['fecha']
  canales   = evento['canales']

  # Informacion del evento
  titulo01 = "[COLOR skyblue] " + categoria + " - " + fecha + "[/COLOR]"
  plugintools.add_item( title = titulo01 , isPlayable = True, folder = True )

  # Canales del evento
  for canal in canales:
    canal_nombre = canal['canal']
    canal_enlace = canal['enlace']
    etiqueta = "[COLOR red][" + canal_nombre + "][/COLOR] " + titulo
    enlace   = "plugin://program.plexus/?url=" + canal_enlace + "&mode=1&name=" + canal_nombre + " " + titulo
    plugintools.add_item( 
      title      = etiqueta , 
      url        = enlace , 
      isPlayable = True, 
      folder     = False 
    )

# Main loop
run()